package game;

public interface Collision {
	public void action();
}
